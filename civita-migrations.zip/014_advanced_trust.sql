
-- ============================================
-- Advanced Trust Tables
-- ============================================

CREATE TABLE IF NOT EXISTS trust_score_decay (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  decay_rate NUMERIC DEFAULT 0.01,
  last_decay_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS trust_score_weights (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL,
  weight NUMERIC NOT NULL DEFAULT 1.0,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS trust_daily_gains (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  gain_amount NUMERIC NOT NULL,
  source TEXT NOT NULL,
  date DATE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS feedback_pairs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  from_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  to_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  context TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS feedback_cooldowns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  target_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  cooldown_until TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS trust_appeals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'reviewed', 'approved', 'rejected')),
  reviewer_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE trust_score_decay ENABLE ROW LEVEL SECURITY;
ALTER TABLE trust_score_weights ENABLE ROW LEVEL SECURITY;
ALTER TABLE trust_daily_gains ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback_pairs ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback_cooldowns ENABLE ROW LEVEL SECURITY;
ALTER TABLE trust_appeals ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view their own data"
  ON trust_score_decay FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can view their appeals"
  ON trust_appeals FOR SELECT
  USING (user_id = auth.uid() OR reviewer_id = auth.uid());

CREATE POLICY "Users can create appeals"
  ON trust_appeals FOR INSERT
  WITH CHECK (user_id = auth.uid());


